#define SBRK_EAGER 1
#define SBRK_LAZY  2
