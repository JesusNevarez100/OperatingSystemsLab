#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user/user.h"

int main(int argc, char *argv[])
{

    int i, p1[2], p2[2];

    if (pipe(p1) == -1 || pipe(p2) == -1)
    {
        printf("error");
        exit(1);
    }
    
    for (i = 1; i < argc; i++){

        if (fork() == 0){
            // Child
            close(p1[1]); // Close write end 
            close(p2[0]); // Close read end

            if (read(p1[0], &argv[i], 12) <= 0)
            {
                break;
            }
            printf("%d: child received:\t %s\n", getpid(), argv[i]);
            write(p2[1], &argv[i], 12);


        } else {
            close(p1[0]); // parent doesnt read from p1
            close(p2[1]); // Parent doesnt write to p2

            write(p1[1], &argv[i], 12);

            if (read(p2[0], &argv[i], 12) <= 0)
                break;

            printf("%d: parent received:\t %s\n", getpid(), argv[i]);

        }
        
    }
    exit(0);
}