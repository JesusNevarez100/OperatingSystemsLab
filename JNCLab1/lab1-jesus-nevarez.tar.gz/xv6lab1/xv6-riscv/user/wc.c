#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/fcntl.h"
#include "user/user.h"

char buf[512];

struct options {
  int fd;
  char *name;
  int lines;
  int words; 
  int chars;
};

void
wc(struct options *opt)
{
  int i, n;
  int l, w, c, inword;

  l = w = c = 0;
  inword = 0;
  while((n = read(opt->fd, buf, sizeof(buf))) > 0){
    for(i=0; i<n; i++){
      c++;
      if(buf[i] == '\n')
        l++;
      if(strchr(" \r\t\n\v", buf[i]))
        inword = 0;
      else if(!inword){
        w++;
        inword = 1;
      }
    }
  }
  if(n < 0){
    printf("wc: read error\n");
    exit(1);
  }

  if (opt->lines) 
  {
    printf("%d ", l);
  } 
  if (opt->words)
  {
    printf("%d ", w);
  }
  if (opt->chars)
  {
    printf("%d ", c);
  }
  if (!opt->chars & !opt->words & !opt->lines)
  {
    printf("%d %d %d ", l, w, c);
  }
  printf("%s\n", opt->name);
}

int
main(int argc, char *argv[])
{
  
    // Create
    // -l := number of lines
    // -w := number of words
    // -c := number of chars
  
  int i;
  struct options opt = {0, 0, 0, 0, 0};



  if(argc <= 1){
    opt.fd = 0;
    opt.name = "";
    wc(&opt);
    exit(0);
  }

  for(i = 1; i < argc; i++)
  {
    if (argv[i][0] == '-')
    {
      if (strcmp(&argv[i][1], "l") == 0){
        opt.lines = 1;
      } 
      else if(strcmp(&argv[i][1], "w") == 0) 
      {
        opt.words = 1;
      }
      else if(strcmp(&argv[i][1], "c") == 0)
      {
        opt.chars = 1;
      } 
      
      else {
        printf("Unknown option: %s\n", argv[i]);
        exit(1);
      }
    } 
    
    else 
    {
      if ((opt.fd = open(argv[i], O_RDONLY)) < 0)
      {
        printf("wc: cannot open %s\n", argv[i]);
        exit(1);
      }
      opt.name = argv[i];
      wc(&opt);
      close(opt.fd);
    }

  }
  exit(0);
}
