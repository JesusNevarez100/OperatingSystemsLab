#include "kernel/types.h"
#include "user/user.h"

int main() {
    cps();
    exit(0);
}
